#pragma once

struct MinerAttribute
{
    int Water = 0;
    int MaxWater = 0;
    int Gold = 0;
    int MaxGold = 0;
    int OreNum = 0;
    int MaxOreNum = 0;
    bool IsRest = false;
};
